
//2022.12.7
#include<stdio.h>
#include<windows.h>
int main()
{	int i;
	for(i=1;i>0;i++) {
		int choose;
		printf("-----------------------------\n");	
		printf("         ��ӭʹ��ʱ��\n");
		printf("[ʱ�� 1]  [��ʱ�� 2]  [����ʱ 3]\n");
		printf("-----------------------------\n");	
		scanf("%d",&choose);
		system("cls");
		if(choose==1)
		{
			int hour,minute,second,month,date,year,countdown,week,circulate,count;					
			for(circulate=1;circulate>0;circulate++)		
			{ 		
				printf("-----------------------------\n");	
				printf("    ��ǰʱ��\n");				 
				scanf("%d",&hour);
				system("cls");
				printf("-----------------------------\n");	
				printf("      ��ǰ�֣�\n");				
				scanf("%d",&minute);
				system("cls");
				printf("-----------------------------\n");	
				printf("     ��ǰ�룺\n"); 
				scanf("%d",&second);
				system("cls");
				printf("-----------------------------\n");	
				printf("    ��ǰ�꣺\n");
				scanf("%d",&year);
				system("cls");
				printf("-----------------------------\n");	
				printf("    ��ǰ�£�\n"); 
				scanf("%d",&month);	
				system("cls");
				printf("-----------------------------\n");	
				printf("    ��ǰ�գ�\n"); 	
				scanf("%d",&date);
				system("cls");							
				while(1)	
				{
					second++;			
					if(second==60)		
					{
						minute++;				
						second=0;		
					}
					if(minute==60)		
					{
						hour++;		
						minute=0;			 
					}
					if(hour==24)		
					{
						if(year%4!=0)	 
						{
							if(month==2)	
	  						{	
						 		date++;	 
						 		if(date>28)
								{
	 								month++;		
	 								date=1;
								}
	   										
					 		}
							if(month==1||month==3||month==5||month==7||month==8||month==10||month==12)   
	   						{
	    						date++;			 
	    							if(date>31)		 
	    							{
	     								month++;		
	     								date=1;		
	   								}
	  						}				
	  						if(month==4||month==6||month==9||month==11)
	  						{		 
	  							date++;			
	  								if(date>30)		
	  								{
	  									month++;		
	  									date=1;		
									}	
							}
						}		
						else		
					    {
							if(month==2)		
		  					{
		  						date++;		
		  					 	if(date>29)
		    					{
		     						month++;		
		     						date=1;			
		   						}
								}
							if(month==1||month==3||month==5||month==7||month==8||month==10||month==12)   		
		   					{
		    					date++;			
		    						if(date>31)			
		    						{
		     							month++;		
		     							date=1;			
		   							}
		  					}
		  					if(month==4||month==6||month==9||month==11)
		  							if(date>30)		
		  							{
		  								month++;	
		  								date=1;		
									}
									date++;			
					}
					if(month>12)		
					{
						year++;		
						month=1;		
					}
					hour=0;							 		
				}
				Sleep(990);			
				system("cls");			
				printf("-----------------------------\n");	
				printf("          %02d:%02d:%02d       \n",hour,minute,second);
				printf("-----------------------------\n");
				printf("     %d��    |   %d��%��   \n",year,month,date);
				printf("-----------------------------\n");	
				switch((week=(date+2*month+3*(month+1)/5+year+year/4-year/100+year/400)%7)+1)
				{
					case 1:
						printf("           ����һ\n");
						break;
					case 2:
						printf("           ���ڶ�\n"); 
						break;
					case 3: 
						printf("           ������\n");
						break;
					case 4: 
						printf("           ������\n");
						break;
					case 5:
						printf("           ������\n"); 
						break;
					case 6:
						printf("           ������\n");
						break;
					case 7:
						printf("           ������\n"); 
						break;
					default:
						printf("erro!");break;
				 } 
				 printf("-----------------------------\n");	
		
			} 
		}
	} 
		if(choose==2)
		{
			int hour,minute,second,choose_1,choose_2,count;	
			second=0,minute=0,hour=0;
			printf("-----------------------------\n");
			printf("         [1 ����ʱʼ]\n");
			printf("-----------------------------\n");
			scanf("%d",&choose_1);
				while(choose_1)
				{
					second++;
					if(second>=60)
					{
						minute++;
						second=0;
					}
					if(second>=60)
					{
						hour++;
						minute=0;				
					}
					Sleep(990);
					system("cls");
					printf("-----------------------------\n");
					printf("   02d:%02d:%02d\n",hour,minute,second);
					printf("[1 ��ͣ] [2 �ƴ�(������)]");
					printf("-----------------------------\n");
					if(choose==1)
					{
						break;
					 } 
					/*scanf("%d", &choose_2);
					if (choose == 1)
					{
						system("pause");
					}
					else { ++count; printf("%d %02d:%02d:%02d", count, hour, minute, second); }*/
				}
		}	
		
		if(choose==3)
		{
			int hour,minute,second;
			printf("-----------------------------\n");
			printf("   ����ʱ��\nʱ");
			scanf("%d",&hour);
			printf("-----------------------------\n");
			system("cls");
			printf("-----------------------------\n");
			printf("�֣�\n");
			scanf("%d",&minute);
			printf("-----------------------------\n");
			system("cls");
			printf("-----------------------------\n");
			printf("�룺\n");
			scanf("%d",&second);
			printf("-----------------------------\n");
			system("cls");
			while(hour>0||minute>0||second>0)
			{
				if(second>0)
					second--;
				else 
				{
					second=59;
					if(minute>0)
					minute--;
					else
					{
						minute=59;
						hour--;
					}
				}
				Sleep(990); 
				system("cls");
				printf("-----------------------------\n");
				printf("  %02d:%02d:%02d\n",hour,minute,second);
				printf("-----------------------------\n");
				if(hour==0&&minute==0&&second==0)
				{
					system("cls"); 
					printf("-----------------------------\n");
					printf("	����ʱ����\a\n");
					printf("-----------------------------\n");
					Sleep(5000);
					system("cls");
					break;	
				}
			} 
			 
		}				
	}
}
